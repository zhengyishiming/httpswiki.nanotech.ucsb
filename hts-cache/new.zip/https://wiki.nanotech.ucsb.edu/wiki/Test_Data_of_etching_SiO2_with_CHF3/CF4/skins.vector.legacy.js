
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Test Data of etching SiO2 with CHF3/CF4/skins.vector.legacy.js - UCSB Nanofab Wiki</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!1,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"d0e86b2bb68cfbca10650048","wgCSPNonce":!1,"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":0,"wgPageName":"Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js","wgTitle":"Test Data of etching SiO2 with CHF3/CF4/skins.vector.legacy.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js","wgRelevantArticleId":0,"wgIsProbablyEditable":!1,
"wgRelevantPageIsProbablyEditable":!1,"wgRestrictionCreate":[],"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgEditSubmitButtonLabelPublish":!1};RLSTATE={"site.styles":"ready","noscript":"ready","user.styles":"ready","user":"ready","user.options":"loading","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","skins.vector.legacy.js","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.visualEditor.desktopArticleTarget.noscript%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.4"/>
<meta name="robots" content="noindex,nofollow"/>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="UCSB Nanofab Wiki (en)"/>
<link rel="EditURI" type="application/rsd+xml" href="https://wiki.nanotech.ucsb.edu/w/api.php?action=rsd"/>
<link rel="alternate" type="application/atom+xml" title="UCSB Nanofab Wiki Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject page-Test_Data_of_etching_SiO2_with_CHF3_CF4_skins_vector_legacy_js rootpage-Test_Data_of_etching_SiO2_with_CHF3_CF4_skins_vector_legacy_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice" class="mw-body-content"></div>
	<div class="mw-indicators mw-body-content">
	</div>
	<h1 id="firstHeading" class="firstHeading" lang="en">Test Data of etching SiO2 with CHF3/CF4/skins.vector.legacy.js</h1>
	<div id="bodyContent" class="mw-body-content">
		<div id="siteSub" class="noprint">From UCSB Nanofab Wiki</div>
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="noarticletext mw-content-ltr" dir="ltr" lang="en">
<p>There is currently no text in this page.
You can <a href="/wiki/Special:Search/Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js" title="Special:Search/Test Data of etching SiO2 with CHF3/CF4/skins.vector.legacy.js">search for this page title</a> in other pages, or <span class="plainlinks"><a rel="nofollow" class="external text" href="https://wiki.nanotech.ucsb.edu/w/index.php?title=Special:Log&amp;page=Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js">search the related logs</a></span>, but you do not have permission to create this page.
</p>
</div></div><div class="printfooter">Retrieved from "<a dir="ltr" href="https://wiki.nanotech.ucsb.edu/wiki/Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js">https://wiki.nanotech.ucsb.edu/wiki/Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js</a>"</div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" role="navigation" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Test+Data+of+etching+SiO2+with+CHF3%2FCF4%2Fskins.vector.legacy.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Test+Data+of+etching+SiO2+with+CHF3%2FCF4%2Fskins.vector.legacy.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</nav>


		<div id="left-navigation">
			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" role="navigation" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-main" class="selected new"><a href="/w/index.php?title=Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js&amp;action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c">Page</a></li><li id="ca-talk" class="new"><a href="/w/index.php?title=Talk:Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t">Discussion</a></li></ul>
		
	</div>
</nav>


			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" role="navigation" 
	 >
	<input type="checkbox" class="vector-menu-checkbox vectorMenuCheckbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</nav>


		</div>
		<div id="right-navigation">
			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-views" class="vector-menu-empty emptyPortlet vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" role="navigation" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>


			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" role="navigation" 
	 >
	<input type="checkbox" class="vector-menu-checkbox vectorMenuCheckbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</nav>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search UCSB Nanofab Wiki" title="Search UCSB Nanofab Wiki [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-InvisibleMenu" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-InvisibleMenu-label" role="navigation" 
	 >
	<h3 id="p-InvisibleMenu-label">
		<span>InvisibleMenu</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>


	<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-QuickLinks" class="vector-menu vector-menu-portal portal" aria-labelledby="p-QuickLinks-label" role="navigation" 
	 >
	<h3 id="p-QuickLinks-label">
		<span>QuickLinks</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Lab-Rules"><a href="/wiki/Lab_Rules">Lab Rules</a></li><li id="n-COVID-19-Protocols"><a href="/wiki/COVID-19_User_Policies">COVID-19 Protocols</a></li><li id="n-Common-Questions"><a href="/wiki/FAQs">Common Questions</a></li><li id="n-Staff-List"><a href="/wiki/Staff_List">Staff List</a></li><li id="n-Equipment-Signup"><a href="https://signupmonkey.ece.ucsb.edu" rel="nofollow">Equipment Signup</a></li><li id="n-Chemicals-.2B-MSDS"><a href="/wiki/Chemical_List">Chemicals + MSDS</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Equipment" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Equipment-label" role="navigation" 
	 >
	<h3 id="p-Equipment-label">
		<span>Equipment</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Full-Tool-List"><a href="/wiki/Tool_List">Full Tool List</a></li><li id="n-Lithography"><a href="/wiki/Category:Lithography">Lithography</a></li><li id="n-Vacuum-Deposition"><a href="/wiki/Category:Vacuum_Deposition">Vacuum Deposition</a></li><li id="n-Dry-Etch"><a href="/wiki/Category:Dry_Etch">Dry Etch</a></li><li id="n-Wet-Processing"><a href="/wiki/Category:Wet_Processing">Wet Processing</a></li><li id="n-Thermal-Processing"><a href="/wiki/Category:Thermal_Processing">Thermal Processing</a></li><li id="n-Packaging"><a href="/wiki/Category:Packaging">Packaging</a></li><li id="n-Inspection.2C-Test-.26-Characterization"><a href="/wiki/Category:Inspection,_Test_and_Characterization">Inspection, Test &amp; Characterization</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Recipes and Data" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Recipes and Data-label" role="navigation" 
	 >
	<h3 id="p-Recipes and Data-label">
		<span>Recipes and Data</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Lithography"><a href="/wiki/Lithography_Recipes">Lithography</a></li><li id="n-Vacuum-Deposition"><a href="/wiki/Vacuum_Deposition_Recipes">Vacuum Deposition</a></li><li id="n-Dry-Etching"><a href="/wiki/Dry_Etching_Recipes">Dry Etching</a></li><li id="n-Wet-Etching"><a href="/wiki/Wet_Etching_Recipes">Wet Etching</a></li><li id="n-Thermal-Processing"><a href="/wiki/Thermal_Processing_Recipes">Thermal Processing</a></li><li id="n-Packaging-Tools"><a href="/wiki/Packaging_Recipes">Packaging Tools</a></li><li id="n-Calculators.2FUtilities"><a href="/wiki/Calculators_%2B_Utilities">Calculators/Utilities</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Facility Data" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Facility Data-label" role="navigation" 
	 >
	<h3 id="p-Facility Data-label">
		<span>Facility Data</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Usage"><a href="/wiki/Usage_Data_and_Statistics">Usage</a></li><li id="n-Research"><a href="/wiki/Research">Research</a></li><li id="n-Tech-Talks"><a href="/wiki/Tech_Talks_Seminar_Series">Tech Talks</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js" title="A list of all wiki pages that link here [j]" accesskey="j">What links here</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-print"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p">Printable version</a></li><li id="t-info"><a href="/w/index.php?title=Test_Data_of_etching_SiO2_with_CHF3/CF4/skins.vector.legacy.js&amp;action=info" title="More information about this page">Page information</a></li></ul>
		
	</div>
</nav>


	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="/wiki/UCSB_Nanofab_Wiki:Privacy_policy" title="UCSB Nanofab Wiki:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/UCSB_Nanofab_Wiki:About" title="UCSB Nanofab Wiki:About">About UCSB Nanofab Wiki</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/UCSB_Nanofab_Wiki:General_disclaimer" title="UCSB Nanofab Wiki:General disclaimer">Disclaimers</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/w/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/w/resources/assets/poweredby_mediawiki_132x47.png 1.5x, /w/resources/assets/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</footer>



<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3048424-9', 'auto');
  ga('send', 'pageview');

</script>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":54});});</script></body></html>
