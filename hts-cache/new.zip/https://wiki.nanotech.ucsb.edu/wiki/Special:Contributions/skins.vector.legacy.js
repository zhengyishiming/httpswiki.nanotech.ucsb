
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>User contributions for Skins.vector.legacy.js - UCSB Nanofab Wiki</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":!1,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"01bbc20596002fefbfa75f8e","wgCSPNonce":!1,"wgCanonicalNamespace":"Special","wgCanonicalSpecialPageName":"Contributions","wgNamespaceNumber":-1,"wgPageName":"Special:Contributions/skins.vector.legacy.js","wgTitle":"Contributions/skins.vector.legacy.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":!1,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Special:Contributions/skins.vector.legacy.js","wgRelevantArticleId":0,"wgIsProbablyEditable":!1,"wgRelevantPageIsProbablyEditable":!1,"wgVisualEditor":{
"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgEditSubmitButtonLabelPublish":!1};RLSTATE={"site.styles":"ready","noscript":"ready","user.styles":"ready","user":"ready","user.options":"loading","jquery.makeCollapsible.styles":"ready","mediawiki.interface.helpers.styles":"ready","mediawiki.special":"ready","mediawiki.special.changeslist":"ready","mediawiki.helplink":"ready","mediawiki.widgets.DateInputWidget.styles":"ready","oojs-ui-core.styles":"ready","oojs-ui.styles.indicators":"ready","mediawiki.widgets.styles":"ready","oojs-ui-core.icons":"ready","mediawiki.htmlform.ooui.styles":"ready","mediawiki.htmlform.styles":"ready","skins.vector.styles.legacy":"ready","mediawiki.feedlink":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready"};RLPAGEMODULES=["mediawiki.special.recentchanges","mediawiki.page.ready","mediawiki.special.contributions","mediawiki.htmlform","mediawiki.htmlform.ooui","mediawiki.widgets.UserInputWidget",
"mediawiki.widgets","oojs-ui-widgets","mediawiki.widgets.DateInputWidget","site","mediawiki.page.startup","jquery.makeCollapsible","skins.vector.legacy.js","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@1hzgi",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.visualEditor.desktopArticleTarget.noscript%7Cjquery.makeCollapsible.styles%7Cmediawiki.feedlink%2Chelplink%2Cspecial%7Cmediawiki.htmlform.ooui.styles%7Cmediawiki.htmlform.styles%7Cmediawiki.interface.helpers.styles%7Cmediawiki.special.changeslist%7Cmediawiki.widgets.DateInputWidget.styles%7Cmediawiki.widgets.styles%7Coojs-ui-core.icons%2Cstyles%7Coojs-ui.styles.indicators%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.35.4"/>
<meta name="robots" content="noindex,nofollow"/>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="UCSB Nanofab Wiki (en)"/>
<link rel="EditURI" type="application/rsd+xml" href="https://wiki.nanotech.ucsb.edu/w/api.php?action=rsd"/>
<link rel="alternate" type="application/atom+xml" title="&quot;Special:Contributions/skins.vector.legacy.js&quot; Atom feed" href="/w/api.php?action=feedcontributions&amp;user=Skins.vector.legacy.js&amp;feedformat=atom"/>
<link rel="alternate" type="application/atom+xml" title="UCSB Nanofab Wiki Atom feed" href="/w/index.php?title=Special:RecentChanges&amp;feed=atom"/>
<!--[if lt IE 9]><script src="/w/resources/lib/html5shiv/html5shiv.js"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns--1 ns-special mw-special-Contributions page-Special_Contributions_skins_vector_legacy_js rootpage-Special_Contributions_skins_vector_legacy_js skin-vector action-view skin-vector-legacy">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice" class="mw-body-content"></div>
	<div class="mw-indicators mw-body-content">
	<div id="mw-indicator-mw-helplink" class="mw-indicator"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/Help:User_contributions" target="_blank" class="mw-helplink">Help</a></div>
	</div>
	<h1 id="firstHeading" class="firstHeading" lang="en">User contributions</h1>
	<div id="bodyContent" class="mw-body-content">
		
		<div id="contentSub"><div class="mw-contributions-user-tools">For Skins.vector.legacy.js <span class="mw-changeslist-links"><span><a href="/w/index.php?title=User_talk:Skins.vector.legacy.js&amp;action=edit&amp;redlink=1" class="new" title="User talk:Skins.vector.legacy.js (page does not exist)" data-usertalkpage-link="true">talk</a></span> <span><a href="/w/index.php?title=Special:Log/block&amp;page=User%3ASkins.vector.legacy.js" title="Special:Log/block">block log</a></span> <span><a href="/wiki/Special:ListFiles/Skins.vector.legacy.js" title="Special:ListFiles/Skins.vector.legacy.js">uploads</a></span> <span><a href="/wiki/Special:Log/Skins.vector.legacy.js" title="Special:Log/Skins.vector.legacy.js">logs</a></span></span></div></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text"><div class="mw-userpage-userdoesnotexist error">
<p>User account "Skins.vector.legacy.js" is not registered.
</p>
</div><div class='mw-htmlform-ooui-wrapper oo-ui-layout oo-ui-panelLayout oo-ui-panelLayout-padded oo-ui-panelLayout-framed'><form action='/w/index.php' method='get' enctype='application/x-www-form-urlencoded' class='mw-htmlform mw-htmlform-ooui oo-ui-layout oo-ui-formLayout'><fieldset class='oo-ui-layout oo-ui-labelElement oo-ui-fieldsetLayout mw-collapsible mw-collapsed'><legend role='button' class='oo-ui-fieldsetLayout-header mw-collapsible-toggle'><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-labelElement-label'>Search for contributions</span><span aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-expand oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget'>Expand</span><span aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-collapse oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget'>Collapse</span></legend><div class='oo-ui-fieldsetLayout-group mw-collapsible-content'><div aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled'><div class='oo-ui-layout oo-ui-panelLayout oo-ui-panelLayout-padded oo-ui-panelLayout-framed'><fieldset class='oo-ui-layout oo-ui-labelElement oo-ui-fieldsetLayout'><legend class='oo-ui-fieldsetLayout-header'><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-labelElement-label'>⧼contribs-top⧽</span></legend><div class='oo-ui-fieldsetLayout-group'><div aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled'><div id="mw-htmlform-contribs-top"><div data-mw-modules='mediawiki.widgets.UserInputWidget' id='ooui-php-12' class='mw-htmlform-field-HTMLUserTextField  mw-htmlform-field-autoinfuse oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-target-user-or-ip"},"align":"top","helpInline":true,"$overlay":true,"label":{"html":"IP address or username:"},"classes":["mw-htmlform-field-HTMLUserTextField","","mw-htmlform-field-autoinfuse"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label for='ooui-php-3' class='oo-ui-labelElement-label'>IP address or username:</label></span><div class='oo-ui-fieldLayout-field'><div id='mw-target-user-or-ip' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-textInputWidget oo-ui-textInputWidget-type-text oo-ui-textInputWidget-php mw-widget-userInputWidget' data-ooui='{"_":"mw.widgets.UserInputWidget","$overlay":true,"name":"target","value":"skins.vector.legacy.js","inputId":"ooui-php-3"}'><input type='text' tabindex='0' aria-disabled='false' name='target' value='skins.vector.legacy.js' id='ooui-php-3' class='oo-ui-inputWidget-input' /><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator'></span></div></div></div></div><div data-mw-modules='mediawiki.widgets' id='ooui-php-13' class='mw-htmlform-field-HTMLSelectNamespace namespaceselector mw-htmlform-field-autoinfuse oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"namespace"},"align":"top","helpInline":true,"$overlay":true,"label":{"html":"Namespace:"},"classes":["mw-htmlform-field-HTMLSelectNamespace","namespaceselector","mw-htmlform-field-autoinfuse"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label for='ooui-php-4' class='oo-ui-labelElement-label'>Namespace:</label></span><div class='oo-ui-fieldLayout-field'><div id='namespace' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-dropdownInputWidget oo-ui-dropdownInputWidget-php mw-widget-namespaceInputWidget' data-ooui='{"_":"mw.widgets.NamespaceInputWidget","includeAllValue":"all","exclude":[],"dropdown":{"$overlay":true},"name":"namespace","value":"all","inputId":"ooui-php-4"}'><select tabindex='0' aria-disabled='false' name='namespace' id='ooui-php-4' class='oo-ui-inputWidget-input oo-ui-indicator-down'><option value='all' selected='selected'>all</option><option value='0'>(Main)</option><option value='1'>Talk</option><option value='2'>User</option><option value='3'>User talk</option><option value='4'>UCSB Nanofab Wiki</option><option value='5'>UCSB Nanofab Wiki talk</option><option value='6'>File</option><option value='7'>File talk</option><option value='8'>MediaWiki</option><option value='9'>MediaWiki talk</option><option value='10'>Template</option><option value='11'>Template talk</option><option value='12'>Help</option><option value='13'>Help talk</option><option value='14'>Category</option><option value='15'>Category talk</option></select></div></div></div></div><div id='ooui-php-14' class='mw-htmlform-field-HTMLMultiSelectField contribs-ns-filters mw-input-with-label mw-input-hidden mw-htmlform-flatlist oo-ui-layout oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"ooui-php-15"},"align":"top","helpInline":true,"$overlay":true,"classes":["mw-htmlform-field-HTMLMultiSelectField","contribs-ns-filters mw-input-with-label mw-input-hidden mw-htmlform-flatlist"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label id='ooui-php-7' class='oo-ui-labelElement-label'></label></span><div class='oo-ui-fieldLayout-field'><div aria-disabled='false' aria-labelledby='ooui-php-7' id='ooui-php-15' class='contribs-ns-filters mw-input-with-label mw-input-hidden mw-htmlform-flatlist oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxMultiselectInputWidget' data-ooui='{"_":"OO.ui.CheckboxMultiselectInputWidget","options":[{"data":"nsInvert","label":"Invert selection","disabled":false},{"data":"associated","label":"Associated namespace","disabled":false}],"name":"wpfilters[]","value":[],"classes":["contribs-ns-filters mw-input-with-label mw-input-hidden mw-htmlform-flatlist"]}'><div class='oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-inline'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-field'><span aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxInputWidget'><input type='checkbox' tabindex='0' aria-disabled='false' name='wpfilters[]' value='nsInvert' id='ooui-php-5' class='oo-ui-inputWidget-input' /><span aria-disabled='false' class='oo-ui-checkboxInputWidget-checkIcon oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-check oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget oo-ui-image-invert'></span></span></span><span class='oo-ui-fieldLayout-header'><label for='ooui-php-5' class='oo-ui-labelElement-label'>Invert selection</label></span></div></div><div class='oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-inline'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-field'><span aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxInputWidget'><input type='checkbox' tabindex='0' aria-disabled='false' name='wpfilters[]' value='associated' id='ooui-php-6' class='oo-ui-inputWidget-input' /><span aria-disabled='false' class='oo-ui-checkboxInputWidget-checkIcon oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-check oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget oo-ui-image-invert'></span></span></span><span class='oo-ui-fieldLayout-header'><label for='ooui-php-6' class='oo-ui-labelElement-label'>Associated namespace</label></span></div></div></div></div></div></div><div id='ooui-php-16' class='mw-htmlform-field-HTMLTagFilter mw-tagfilter-input oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"tagfilter"},"align":"top","helpInline":true,"$overlay":true,"label":{"html":"&lt;a href=\"\/wiki\/Special:Tags\" title=\"Special:Tags\"&gt;Tag&lt;\/a&gt; filter:"},"classes":["mw-htmlform-field-HTMLTagFilter","mw-tagfilter-input"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label for='ooui-php-8' class='oo-ui-labelElement-label'><a href="/wiki/Special:Tags" title="Special:Tags">Tag</a> filter:</label></span><div class='oo-ui-fieldLayout-field'><div id='tagfilter' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-textInputWidget oo-ui-textInputWidget-type-text oo-ui-textInputWidget-php' data-ooui='{"_":"OO.ui.TextInputWidget","name":"tagfilter","inputId":"ooui-php-8"}'><input type='text' tabindex='0' aria-disabled='false' name='tagfilter' value='' id='ooui-php-8' class='oo-ui-inputWidget-input' /><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator'></span></div></div></div></div><div id='ooui-php-17' class='mw-htmlform-field-HTMLCheckField  oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-inline' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-show-top-only"},"align":"inline","helpInline":true,"$overlay":true,"label":{"html":"Only show edits that are latest revisions"},"classes":["mw-htmlform-field-HTMLCheckField",""]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-field'><span id='mw-show-top-only' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxInputWidget' data-ooui='{"_":"OO.ui.CheckboxInputWidget","name":"topOnly","value":"1","inputId":"ooui-php-9"}'><input type='checkbox' tabindex='0' aria-disabled='false' name='topOnly' value='1' id='ooui-php-9' class='oo-ui-inputWidget-input' /><span aria-disabled='false' class='oo-ui-checkboxInputWidget-checkIcon oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-check oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget oo-ui-image-invert'></span></span></span><span class='oo-ui-fieldLayout-header'><label for='ooui-php-9' class='oo-ui-labelElement-label'>Only show edits that are latest revisions</label></span></div></div><div id='ooui-php-18' class='mw-htmlform-field-HTMLCheckField  oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-inline' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-show-new-only"},"align":"inline","helpInline":true,"$overlay":true,"label":{"html":"Only show edits that are page creations"},"classes":["mw-htmlform-field-HTMLCheckField",""]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-field'><span id='mw-show-new-only' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxInputWidget' data-ooui='{"_":"OO.ui.CheckboxInputWidget","name":"newOnly","value":"1","inputId":"ooui-php-10"}'><input type='checkbox' tabindex='0' aria-disabled='false' name='newOnly' value='1' id='ooui-php-10' class='oo-ui-inputWidget-input' /><span aria-disabled='false' class='oo-ui-checkboxInputWidget-checkIcon oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-check oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget oo-ui-image-invert'></span></span></span><span class='oo-ui-fieldLayout-header'><label for='ooui-php-10' class='oo-ui-labelElement-label'>Only show edits that are page creations</label></span></div></div><div id='ooui-php-19' class='mw-htmlform-field-HTMLCheckField mw-hide-minor-edits oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-inline' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-show-new-only"},"align":"inline","helpInline":true,"$overlay":true,"label":{"html":"Hide minor edits"},"classes":["mw-htmlform-field-HTMLCheckField","mw-hide-minor-edits"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-field'><span id='mw-show-new-only' aria-disabled='false' class='mw-hide-minor-edits oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-checkboxInputWidget' data-ooui='{"_":"OO.ui.CheckboxInputWidget","name":"hideMinor","value":"1","inputId":"ooui-php-11","classes":["mw-hide-minor-edits"]}'><input type='checkbox' tabindex='0' aria-disabled='false' name='hideMinor' value='1' id='ooui-php-11' class='oo-ui-inputWidget-input' /><span aria-disabled='false' class='oo-ui-checkboxInputWidget-checkIcon oo-ui-widget oo-ui-widget-enabled oo-ui-iconElement-icon oo-ui-icon-check oo-ui-iconElement oo-ui-labelElement-invisible oo-ui-iconWidget oo-ui-image-invert'></span></span></span><span class='oo-ui-fieldLayout-header'><label for='ooui-php-11' class='oo-ui-labelElement-label'>Hide minor edits</label></span></div></div></div></div></div></fieldset></div><div class='oo-ui-layout oo-ui-panelLayout oo-ui-panelLayout-padded oo-ui-panelLayout-framed'><fieldset class='oo-ui-layout oo-ui-labelElement oo-ui-fieldsetLayout'><legend class='oo-ui-fieldsetLayout-header'><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-labelElement-label'>⧼contribs-date⧽</span></legend><div class='oo-ui-fieldsetLayout-group'><div aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled'><div id="mw-htmlform-contribs-date"><div data-mw-modules='mediawiki.widgets.DateInputWidget' id='ooui-php-22' class='mw-htmlform-field-HTMLDateTimeField  mw-htmlform-datetime-field mw-htmlform-field-autoinfuse oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-date-start"},"align":"top","helpInline":true,"$overlay":true,"label":{"html":"From date:"},"classes":["mw-htmlform-field-HTMLDateTimeField"," mw-htmlform-datetime-field","mw-htmlform-field-autoinfuse"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label for='ooui-php-20' class='oo-ui-labelElement-label'>From date:</label></span><div class='oo-ui-fieldLayout-field'><div id='mw-date-start' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-textInputWidget oo-ui-textInputWidget-type-text oo-ui-textInputWidget-php mw-widget-dateInputWidget' data-ooui='{"_":"mw.widgets.DateInputWidget","longDisplayFormat":false,"precision":"day","$overlay":true,"placeholder":"YYYY-MM-DD","name":"start","inputId":"ooui-php-20"}'><input type='date' tabindex='0' aria-disabled='false' name='start' value='' placeholder='YYYY-MM-DD' id='ooui-php-20' class='oo-ui-inputWidget-input' /><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator'></span></div></div></div></div><div data-mw-modules='mediawiki.widgets.DateInputWidget' id='ooui-php-23' class='mw-htmlform-field-HTMLDateTimeField  mw-htmlform-datetime-field mw-htmlform-field-autoinfuse oo-ui-layout oo-ui-labelElement oo-ui-fieldLayout oo-ui-fieldLayout-align-top' data-ooui='{"_":"mw.htmlform.FieldLayout","fieldWidget":{"tag":"mw-date-end"},"align":"top","helpInline":true,"$overlay":true,"label":{"html":"To date:"},"classes":["mw-htmlform-field-HTMLDateTimeField"," mw-htmlform-datetime-field","mw-htmlform-field-autoinfuse"]}'><div class='oo-ui-fieldLayout-body'><span class='oo-ui-fieldLayout-header'><label for='ooui-php-21' class='oo-ui-labelElement-label'>To date:</label></span><div class='oo-ui-fieldLayout-field'><div id='mw-date-end' aria-disabled='false' class='oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-textInputWidget oo-ui-textInputWidget-type-text oo-ui-textInputWidget-php mw-widget-dateInputWidget' data-ooui='{"_":"mw.widgets.DateInputWidget","longDisplayFormat":false,"precision":"day","$overlay":true,"placeholder":"YYYY-MM-DD","name":"end","inputId":"ooui-php-21"}'><input type='date' tabindex='0' aria-disabled='false' name='end' value='' placeholder='YYYY-MM-DD' id='ooui-php-21' class='oo-ui-inputWidget-input' /><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon'></span><span class='oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator'></span></div></div></div></div></div></div></div></fieldset></div>
<input id="mw-input-limit" name="limit" type="hidden" value="50"/>
<input id="mw-input-title" name="title" type="hidden" value="Special:Contributions"/>
<div class="mw-htmlform-submit-buttons">
<span aria-disabled='false' id='ooui-php-24' class='mw-htmlform-submit oo-ui-widget oo-ui-widget-enabled oo-ui-inputWidget oo-ui-buttonElement oo-ui-buttonElement-framed oo-ui-labelElement oo-ui-flaggedElement-primary oo-ui-flaggedElement-progressive oo-ui-buttonInputWidget' data-ooui='{"_":"OO.ui.ButtonInputWidget","type":"submit","value":"Search","label":"Search","flags":["primary","progressive"],"classes":["mw-htmlform-submit"]}'><button type='submit' tabindex='0' aria-disabled='false' value='Search' class='oo-ui-inputWidget-input oo-ui-buttonElement-button'><span class='oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-invert'></span><span class='oo-ui-labelElement-label'>Search</span><span class='oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-invert'></span></button></span></div>
</div></div></fieldset></form></div><p>No changes were found matching these criteria.
</p></div><div class="printfooter">Retrieved from "<a dir="ltr" href="https://wiki.nanotech.ucsb.edu/wiki/Special:Contributions/skins.vector.legacy.js">https://wiki.nanotech.ucsb.edu/wiki/Special:Contributions/skins.vector.legacy.js</a>"</div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-personal" class="vector-menu" aria-labelledby="p-personal-label" role="navigation" 
	 >
	<h3 id="p-personal-label">
		<span>Personal tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Special%3AContributions%2Fskins.vector.legacy.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Special%3AContributions%2Fskins.vector.legacy.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o">Log in</a></li></ul>
		
	</div>
</nav>


		<div id="left-navigation">
			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-namespaces" class="vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-namespaces-label" role="navigation" 
	 >
	<h3 id="p-namespaces-label">
		<span>Namespaces</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="ca-nstab-special" class="selected"><a href="/wiki/Special:Contributions/skins.vector.legacy.js" title="This is a special page, and it cannot be edited">Special page</a></li></ul>
		
	</div>
</nav>


			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-variants" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-variants-label" role="navigation" 
	 >
	<input type="checkbox" class="vector-menu-checkbox vectorMenuCheckbox" aria-labelledby="p-variants-label" />
	<h3 id="p-variants-label">
		<span>Variants</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</nav>


		</div>
		<div id="right-navigation">
			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-views" class="vector-menu-empty emptyPortlet vector-menu vector-menu-tabs vectorTabs" aria-labelledby="p-views-label" role="navigation" 
	 >
	<h3 id="p-views-label">
		<span>Views</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>


			<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-cactions" class="vector-menu-empty emptyPortlet vector-menu vector-menu-dropdown vectorMenu" aria-labelledby="p-cactions-label" role="navigation" 
	 >
	<input type="checkbox" class="vector-menu-checkbox vectorMenuCheckbox" aria-labelledby="p-cactions-label" />
	<h3 id="p-cactions-label">
		<span>More</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="menu vector-menu-content-list"></ul>
		
	</div>
</nav>


			<div id="p-search" role="search">
	<h3 >
		<label for="searchInput">Search</label>
	</h3>
	<form action="/w/index.php" id="searchform">
		<div id="simpleSearch">
			<input type="search" name="search" placeholder="Search UCSB Nanofab Wiki" title="Search UCSB Nanofab Wiki [f]" accesskey="f" id="searchInput"/>
			<input type="hidden" name="title" value="Special:Search">
			<input type="submit" name="fulltext" value="Search" title="Search the pages for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/>
			<input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>
		</div>
	</form>
</div>

		</div>
	</div>
	
<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a  title="Visit the main page" class="mw-wiki-logo" href="/wiki/Main_Page"></a>
	</div>
	<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-InvisibleMenu" class="vector-menu-empty emptyPortlet vector-menu vector-menu-portal portal portal-first" aria-labelledby="p-InvisibleMenu-label" role="navigation" 
	 >
	<h3 id="p-InvisibleMenu-label">
		<span>InvisibleMenu</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>


	<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-QuickLinks" class="vector-menu vector-menu-portal portal" aria-labelledby="p-QuickLinks-label" role="navigation" 
	 >
	<h3 id="p-QuickLinks-label">
		<span>QuickLinks</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Lab-Rules"><a href="/wiki/Lab_Rules">Lab Rules</a></li><li id="n-COVID-19-Protocols"><a href="/wiki/COVID-19_User_Policies">COVID-19 Protocols</a></li><li id="n-Common-Questions"><a href="/wiki/FAQs">Common Questions</a></li><li id="n-Staff-List"><a href="/wiki/Staff_List">Staff List</a></li><li id="n-Equipment-Signup"><a href="https://signupmonkey.ece.ucsb.edu" rel="nofollow">Equipment Signup</a></li><li id="n-Chemicals-.2B-MSDS"><a href="/wiki/Chemical_List">Chemicals + MSDS</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Equipment" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Equipment-label" role="navigation" 
	 >
	<h3 id="p-Equipment-label">
		<span>Equipment</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Full-Tool-List"><a href="/wiki/Tool_List">Full Tool List</a></li><li id="n-Lithography"><a href="/wiki/Category:Lithography">Lithography</a></li><li id="n-Vacuum-Deposition"><a href="/wiki/Category:Vacuum_Deposition">Vacuum Deposition</a></li><li id="n-Dry-Etch"><a href="/wiki/Category:Dry_Etch">Dry Etch</a></li><li id="n-Wet-Processing"><a href="/wiki/Category:Wet_Processing">Wet Processing</a></li><li id="n-Thermal-Processing"><a href="/wiki/Category:Thermal_Processing">Thermal Processing</a></li><li id="n-Packaging"><a href="/wiki/Category:Packaging">Packaging</a></li><li id="n-Inspection.2C-Test-.26-Characterization"><a href="/wiki/Category:Inspection,_Test_and_Characterization">Inspection, Test &amp; Characterization</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Recipes and Data" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Recipes and Data-label" role="navigation" 
	 >
	<h3 id="p-Recipes and Data-label">
		<span>Recipes and Data</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Lithography"><a href="/wiki/Lithography_Recipes">Lithography</a></li><li id="n-Vacuum-Deposition"><a href="/wiki/Vacuum_Deposition_Recipes">Vacuum Deposition</a></li><li id="n-Dry-Etching"><a href="/wiki/Dry_Etching_Recipes">Dry Etching</a></li><li id="n-Wet-Etching"><a href="/wiki/Wet_Etching_Recipes">Wet Etching</a></li><li id="n-Thermal-Processing"><a href="/wiki/Thermal_Processing_Recipes">Thermal Processing</a></li><li id="n-Packaging-Tools"><a href="/wiki/Packaging_Recipes">Packaging Tools</a></li><li id="n-Calculators.2FUtilities"><a href="/wiki/Calculators_%2B_Utilities">Calculators/Utilities</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-Facility Data" class="vector-menu vector-menu-portal portal" aria-labelledby="p-Facility Data-label" role="navigation" 
	 >
	<h3 id="p-Facility Data-label">
		<span>Facility Data</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="n-Usage"><a href="/wiki/Usage_Data_and_Statistics">Usage</a></li><li id="n-Research"><a href="/wiki/Research">Research</a></li><li id="n-Tech-Talks"><a href="/wiki/Tech_Talks_Seminar_Series">Tech Talks</a></li></ul>
		
	</div>
</nav>

<!-- Please do not use role attribute as CSS selector, it is deprecated. -->
<nav id="p-tb" class="vector-menu vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation" 
	 >
	<h3 id="p-tb-label">
		<span>Tools</span>
	</h3>
	<!-- Please do not use the .body class, it is deprecated. -->
	<div class="body vector-menu-content">
		<!-- Please do not use the .menu class, it is deprecated. -->
		<ul class="vector-menu-content-list"><li id="feedlinks"><a href="/w/api.php?action=feedcontributions&amp;user=Skins.vector.legacy.js&amp;feedformat=atom" id="feed-atom" rel="alternate" type="application/atom+xml" class="feedlink" title="Atom feed for this page">Atom</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-print"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p">Printable version</a></li></ul>
		
	</div>
</nav>


	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-places" >
		<li id="footer-places-privacy"><a href="/wiki/UCSB_Nanofab_Wiki:Privacy_policy" title="UCSB Nanofab Wiki:Privacy policy">Privacy policy</a></li>
		<li id="footer-places-about"><a href="/wiki/UCSB_Nanofab_Wiki:About" title="UCSB Nanofab Wiki:About">About UCSB Nanofab Wiki</a></li>
		<li id="footer-places-disclaimer"><a href="/wiki/UCSB_Nanofab_Wiki:General_disclaimer" title="UCSB Nanofab Wiki:General disclaimer">Disclaimers</a></li>
	</ul>
	<ul id="footer-icons" class="noprint">
		<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/w/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/w/resources/assets/poweredby_mediawiki_132x47.png 1.5x, /w/resources/assets/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
	</ul>
	<div style="clear: both;"></div>
</footer>



<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3048424-9', 'auto');
  ga('send', 'pageview');

</script>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":68});});</script></body></html>
